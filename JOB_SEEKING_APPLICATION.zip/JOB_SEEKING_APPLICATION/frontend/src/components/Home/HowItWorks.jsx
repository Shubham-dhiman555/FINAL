import React from "react";
import { FaUserPlus } from "react-icons/fa";
import { FaSearch } from "react-icons/fa";
import { FaFileAlt } from "react-icons/fa";

const HowItWorks = () => {
  return (
    <>
   
      <div className="container-fluid p-5  working bg-light">
        <div className="m-4 mb-5">
          <center className=" fs-3 fw-bold ">OUR WORKING PROCESS</center>
        </div>
        <div className="row justify-content-center mainrow">
          <div className="col-lg-6">
            <div className="row processrow ">
          <div className="col-lg-6 ">
            <div className="card processcard p-3  m-2 bg-light ">
 <div className="text-center">  <FaUserPlus className="  text-success "></FaUserPlus></div>
  <div class="card-body text-center ">
    <p class="card-text ">
      <b >01. Create Account</b>
      <p className="mt-2">Sign Up Your Profile</p>
    </p>
  </div>
  
</div></div>
</div>
<div class="row justify-content-center processrow ">
          <div className="col-lg-6 ">
          <div className="card processcard p-3  m-2 bg-light" >
 <div className="text-center">  < FaSearch  className=" text-success"></ FaSearch ></div>
  <div class="card-body text-center">
    <p class="card-text  ">
      <b >02. Find a Job/Post a Job</b>
      <p className="mt-2 ">Choose a Suitable Job</p>
    </p>
  </div>
</div>
          </div>
          </div>
          <div className="row justify-content-end processrow ">
          <div className="col-lg-6 ">
          <div className="card processcard p-3 m-2 bg-light ">
 <div className="text-center">  <FaFileAlt className=" text-success"></FaFileAlt></div>
  <div class="card-body text-center ">
    <p class="card-text ">
      <b >03. Apply/Recruitment</b>
      <p className="mt-2 ">Apply Job /Recruitment</p>
    </p>
  </div>
</div>
          </div>
</div>
        
        
        
        
        </div>
        <div className="col-lg-6 bg-light">
          <img src="https://workology.im/wp-content/uploads/2023/06/Isle-of-Man-Jobs-Opportunities-768x513.jpg" className="w-100 h-100 pt-3"></img>

        </div>
        
        </div>

      </div>
      
    </>
  );
};

export default HowItWorks;