import React, { useContext, useEffect, useState } from "react";
import axios from "axios";
import toast from "react-hot-toast";
import { useNavigate } from "react-router-dom";
import { Context } from "../../main";
const PostJob = () => {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState("");
  const [country, setCountry] = useState("");
  const [city, setCity] = useState("");
  const [location, setLocation] = useState("");
  const [salaryFrom, setSalaryFrom] = useState("");
  const [salaryTo, setSalaryTo] = useState("");
  const [fixedSalary, setFixedSalary] = useState("");
  const [salaryType, setSalaryType] = useState("default");

  const { isAuthorized, user } = useContext(Context);
  const reset=()=>{
    setTitle("");
    setCity("");
    setCategory("");
    setCountry("");
    setDescription("");
    setFixedSalary("");
    setLocation("");
    setSalaryFrom("");
    setSalaryTo("");
    setSalaryType("default");
    
  }

  const handleJobPost = async (e) => {
   



    e.preventDefault();
    if (salaryType === "Fixed Salary") {
      setSalaryFrom("");
      setSalaryFrom("");
    } else if (salaryType === "Ranged Salary") {
      setFixedSalary("");
    } else {
      setSalaryFrom("");
      setSalaryTo("");
      setFixedSalary("");
    }
    await axios
      .post(
        "http://localhost:8000/api/v1/job/post",
        fixedSalary.length >= 4
          ? {
              title,
              description,
              category,
              country,
              city,
              location,
              fixedSalary,
            }
          : {
              title,
              description,
              category,
              country,
              city,
              location,
              salaryFrom,
              salaryTo,
            },
        {
          withCredentials: true,
          headers: {
            "Content-Type": "application/json",
          },
        }
      )
      .then((res) => {
        toast.success(res.data.message);
      })
      .catch((err) => {
        toast.error(err.response.data.message);
      });
  };

  const navigateTo = useNavigate();
  if (!isAuthorized || (user && user.role !== "Employer")) {
    navigateTo("/");
  }

  return (
    <>
     <div class="container-fluid mb-3">
    <div class="jobbanner">
    <p class="fw-bold fs-1 ">
    POST A NEW JOB
    </p>
    </div>
    </div>

    <div className="container p-5">
     
      <form onSubmit={handleJobPost} className="p-4 postjob">  
      <div className="row mt-2" >
        <div className="col-md-6 mb-4">
        <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Job Title" required
              />

          

        </div>
        <div className="col-md-6 mb-4">
        <select
                value={category}
                onChange={(e) => setCategory(e.target.value)} className="cgselect pb-1"  required
              >
                <option value="">Select Category</option>
                <option value="Graphics & Design">Graphics & Design</option>
                <option value="Mobile App Development">
                  Mobile App Development
                </option>
                <option value="Frontend Web Development">
                  Frontend Web Development
                </option>
               
                <option value="Account & Finance">Account & Finance</option>
                <option value="Artificial Intelligence">
                  Artificial Intelligence
                </option>
                <option value="Video Animation">Video Animation</option>
                <option value="MEAN Stack Development">
                  MEAN STACK Development
                </option>
                <option value="MERN Stack Development">
                  MERN STACK Development
                </option>
                <option value="Data Entry Operator">Data Entry Operator</option>
              </select>


        </div>

      </div>
      <div className="row">
        <div className="col-md-6 mb-4">
        <input
                type="text"
                value={country}
                onChange={(e) => setCountry(e.target.value)} required
                placeholder="Country"
              />

        </div>
        <div className="col-md-6 mb-4">
        <input
                type="text"
                value={city}
                onChange={(e) => setCity(e.target.value)} required
                placeholder="City"
              />


        </div>

      </div>
     <div className="row">
     <div className="col-md-6 mb-4">
        <input
                type="text"
                value={location}
                onChange={(e) => setLocation(e.target.value)} required
                placeholder="Location"
              />


        </div>
     </div>



      <div className="row">
        <div className="col">
        <select
                value={salaryType}
                onChange={(e) => setSalaryType(e.target.value)} className="w-100 mb-2 cgselect " required
              >
                <option value="default">Select Salary Type</option>
                <option value="Fixed Salary">Fixed Salary</option>
                <option value="Ranged Salary">Ranged Salary</option>
              </select>

        {salaryType === "default" ? (<p className="text-danger mt">*Please provide salary type</p>
                  
                ) : salaryType === "Fixed Salary" ? (
                  <input
                    type="text"
                    placeholder="Enter Fixed Salary"
                    value={fixedSalary}
                    onChange={(e) => setFixedSalary(e.target.value)} className="me-4 mt-2 mb-4 salary w-50" required
                  />
                ) : (
                  <div className="ranged_salary d-flex">
                    <input
                      type="number"
                      placeholder="Salary From"
                      value={salaryFrom}
                      onChange={(e) => setSalaryFrom(e.target.value)}className="me-4  mt-2 mb-4 fom-control" required
                    />
                    <input
                      type="number"
                      placeholder="Salary To"
                      value={salaryTo}
                      onChange={(e) => setSalaryTo(e.target.value)} required className="  mt-2 mb-4"
                    />
                  </div>
                )}
              </div>

         
        

      </div>
      <div className="row">
        <div className="col">
        <textarea
              rows="10"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Job Description" className="mt-2 w-100 mb-4" required
            />


        </div>

      </div>
      <div className="row">
        <div className="col">
       <center> <button type="submit" className="btn btn-success w-100 fw-bold mb-4 createjob">CREATE JOB</button></center>
       <button type="Reset" className=" fw-bold mb-2 resetbtn" onClick={reset}>RESET</button>
        </div>

      </div>

</form>
    </div>
     
    </>
  );
};

export default PostJob;