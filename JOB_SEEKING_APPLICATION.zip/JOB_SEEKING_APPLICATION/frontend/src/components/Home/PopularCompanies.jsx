import React from "react";
import { SiTesla } from "react-icons/si";
import { FcGoogle } from "react-icons/fc";
import { FaApple } from "react-icons/fa";
import { FaAmazon } from "react-icons/fa";
import { FaMicrosoft } from "react-icons/fa6";
import { FaFacebook } from "react-icons/fa";
import { SiOracle } from "react-icons/si";
import { SiNetflix } from "react-icons/si";
import { SiIbm } from "react-icons/si";
import { SiIntel } from "react-icons/si";
import { SiAdobeacrobatreader } from "react-icons/si";
import { DiCisco } from "react-icons/di";
const PopularCompanies = () => {
  const companies = [
    {
      id: 1,
      title: "Google",
      location: "Mountain View, CA",
      openPositions: 10,
      icon: <FcGoogle />,
    },
    {
      id: 2,
      title: "Apple",
      location: "Cupertino, CA",
      openPositions: 8,
      icon: <FaApple />,
    },
    {
      id: 3,
      title: "Amazon",
      location: "Seattle, WA",
      openPositions: 12,
      icon: <FaAmazon />,
      
    },
    {
      id: 4,
      title: "Microsoft",
      location: "Street 10 Karachi, Pakistan",
      openPositions: 10,
      icon: <FaMicrosoft />,
    },
    {
      id: 5,
      title: "Facebook",
      location: "Menlo Park, CA",
      openPositions: 7,
      icon: <FaFacebook />,
    },
    {
      id: 6,
      title: "Tesla",
      location: "Palo Alto, CA",
      openPositions: 5,
      icon: <SiTesla />,
    },
    {
      id: 7,
      title: "Netflix",
      location: "Los Gatos, CA",
      openPositions: 6,
      icon: <SiNetflix />,
    },
    {
      id: 8,
      title: "IBM",
      location: "Armonk, NY",
      openPositions: 9,
      icon: <SiIbm/>,
    },
    {
      id: 9,
      title: "Intel",
      location: "Santa Clara, CA",
      openPositions: 11,
      icon: <SiIntel />,
    },
    {
      id: 10,
      title: "Adobe",
      location: "San Jose, CA",
      openPositions: 6,
      icon: <SiAdobeacrobatreader />,
    },
    {
      id: 11,
      title: "Oracle",
      location: "Redwood City, CA",
      openPositions: 8,
      icon: <SiOracle/>,
    },
    {
      id: 12,
      title: "Cisco",
      location: "San Jose, CA",
      openPositions: 7,
      icon: <DiCisco />,
    }
  ];
  return (
  <>
  <center>
    <div className="container-fluid p-5 bg-light">
     <center> <b className="fs-3"> POPULAR COMPANIES</b>
     </center>
      <div className="row mt-5 ">
        {companies.map((element) => {
          return (
            <div className="col-lg-2 col-sm-6 col-md-4 mb-4" >
             <div className="card companycard  bg-light" key={element.id} >
                <div className="content pt-2 pb-2">
                  <div className="icon fs-1 text-success companyicon ">{element.icon}</div>
                  <div className="text">
                    <p className="fw-bold fs-6 text-dark pt-2">{element.title}</p>
                   
                  </div>
                </div>
               
              </div>

            </div>
          );
        })}
      </div>
      
    </div>
    </center>
  </>
    
  );
};

export default PopularCompanies;