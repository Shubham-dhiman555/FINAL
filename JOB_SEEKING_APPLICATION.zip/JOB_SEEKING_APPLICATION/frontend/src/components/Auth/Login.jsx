import React, { useContext, useState } from "react";
import toast from "react-hot-toast";
import { Context } from "../../main";
import { Link, Navigate } from "react-router-dom";
import axios from "axios";

const Login=()=>{
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [role, setRole] = useState("");
    const { isAuthorized, setIsAuthorized } = useContext(Context);
    const handleLogin = async (e) => {
      e.preventDefault();
      try {
        const {data} = await axios.post(
          "http://localhost:8000/api/v1/user/login",
          { email, password, role },
          {
            headers: {
              "Content-Type": "application/json",
            },
            withCredentials: true,
          }
        );
        toast.success(data.message);
        setEmail("");
        setPassword("");
        setRole("");
        setIsAuthorized(true);
      } catch (error) {
        toast.error(error.response.data.message);
      }
    };
   
    if(isAuthorized){
      return <Navigate to={'/'}/>
    }
    return(
        <> 
        <div  className="container-fluid   loginform ">
            
                <div className="row justify-content-center  m-5">
                <div className="col-lg-4 m-5 p-4 pt-0 bg-white login ">
                <center><img src="/logon.png" class="logo2"></img></center>
                <h5 className="fw-bold p-3 pt-0 text-center">LOGIN TO YOUR ACCOUNT</h5>
                <div className="form-group d-flex">
                    <label><i class="fa fa-user mt-2 fs-4 me-3 ms-1 "></i></label>
                    <select value={role} onChange={(e) => setRole(e.target.value)} >
                  <option value="">Select Role </option>
                  <option value="Employer"  className="text-black">Employer</option>
                  <option value="Job Seeker"  className="text-black">Job Seeker</option>
                </select>
                </div>
                <div className="form-group d-flex justify-content-between m-2">
                    <label><i className="fa fa-user text-start mt-3 fs-4 me-2"></i></label>
                    <input type="email" placeholder="Email ID" className="form-control pb-0"  value={email}
                  onChange={(e) => setEmail(e.target.value)}/>

                </div>
                <div className="form-group d-flex justify-content-between m-2">
                    <label><i className="fa fa-lock text-start mt-3 fs-4 me-2"></i></label>
                    <input type="password" placeholder="Password" className="form-control pb-0 " value={password}
                  onChange={(e) => setPassword(e.target.value)}/>

                </div>
                 <br/>
                   <center> <button type="submit" className="submit mt-0 p-2 ps-4 pe-4 fw-bold text-white" onClick={handleLogin}> Login</button>
                   </center>
                <center className="mt-4">
                Don't have account?&nbsp;
              <Link to='/register' className="   text-danger createac">Create Account</Link>
                </center>
            </div>
          </div>
        </div>
        </>
        );
};
export default Login;