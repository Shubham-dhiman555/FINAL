import React, { useContext, useEffect, useState } from "react";
import { Context } from "../../main";
import axios from "axios";
import toast from "react-hot-toast";
import { useNavigate } from "react-router-dom";
import ResumeModal from "./ResumeModal";
import { MdDelete } from "react-icons/md";

const MyApplications = () => {
  const { user } = useContext(Context);
  const [applications, setApplications] = useState([]);
  const [modalOpen, setModalOpen] = useState(false);
  const [resumeImageUrl, setResumeImageUrl] = useState("");

  const { isAuthorized } = useContext(Context);
  const navigateTo = useNavigate();

  useEffect(() => {
    try {
      if (user && user.role === "Employer") {
        axios
          .get("http://localhost:8000/api/v1/application/employer/getall", {
            withCredentials: true,
          })
          .then((res) => {
            setApplications(res.data.applications);
          });
      } else {
        axios
          .get("http://localhost:8000/api/v1/application/jobseeker/getall", {
            withCredentials: true,
          })
          .then((res) => {
            setApplications(res.data.applications);
          });
      }
    } catch (error) {
      toast.error(error.response.data.message);
    }
  }, [isAuthorized]);

  if (!isAuthorized) {
    navigateTo("/");
  }

  const deleteApplication = (id) => {
    try {
      axios
        .delete(`http://localhost:8000/api/v1/application/delete/${id}`, {
          withCredentials: true,
        })
        .then((res) => {
          toast.success(res.data.message);
          setApplications((prevApplication) =>
            prevApplication.filter((application) => application._id !== id)
          );
        });
    } catch (error) {
      toast.error(error.response.data.message);
    }
  };

  const openModal = (imageUrl) => {
    setResumeImageUrl(imageUrl);
    setModalOpen(true);
  };

  const closeModal = () => {
    setModalOpen(false);
  };

  return (
    <section className="my_applications page">
      {user && user.role === "Job Seeker" ? (
        <div className="container-fluid">
          
    <div class="jobbanner">
    <p class="fw-bold fs-1  ">
    MY APPLICATIONS
    </p>
    </div>
   
          {applications.length <= 0 ? (
            <>
              {" "}
              <b className="p-5 fs-4 text-danger">**No Applications Found</b>{" "}
            </>
          ) : (
            applications.map((element) => {
              return (
                <JobSeekerCard
                  element={element}
                  key={element._id}
                  deleteApplication={deleteApplication}
                  openModal={openModal}
                />
              );
            })
          )}
        </div>
      ) : (<>
        <div class="container-fluid mb-5">
        <div class="jobbanner">
        <p class="fw-bold fs-1 ">
         APPLICATIONS FROM JOB SEEKERS
        </p>
        </div>
        </div>
        <div className="container-fluid p-5">
         
          {applications.length <= 0 ? (
            <>
              <p className=" text-danger fs-5">*No Applications Found</p>
            </>
          ) : (
            applications.map((element) => {
              return (
                <EmployerCard
                  element={element}
                  key={element._id}
                  openModal={openModal}
                />
              );
            })
          )}
        </div>
        </>
      )}
      {modalOpen && (
        <ResumeModal imageUrl={resumeImageUrl} onClose={closeModal} />
      )}
    </section>
  );
};

export default MyApplications;

const JobSeekerCard = ({ element, deleteApplication, openModal }) => {
  return (
    <>
      <div  class="container p-5">
  <div className="card mb-4 w-100 p-3  mt-4 myappcard">
    <div className="row g-0">
      <div className="col-md-7 ">
        <div className="card-body pt-4">
          
          <p>
            <span className="fw-bold">Name:</span> {element.name}
          </p>
          <p>
            <span className="fw-bold">Email:</span> {element.email}
          </p>
          <p>
            <span className="fw-bold">Phone:</span> {element.phone}
          </p>
          <p>
            <span className="fw-bold">Address:</span> {element.address}
          </p>
          <p>
            <span className="fw-bold ">CoverLetter:</span> {element.coverLetter}
          </p>

         
        </div>
      </div>
      <div className="col-md-5 ps-3 pt-0">
        <img
            src={element.resume.url}
            alt="resume"
            onClick={() => openModal(element.resume.url)} className="resume"
          />
      </div>
      <p className="text-end">
        <button class="  deletebtn me-4 mt-3" title="Delete Application" onClick={() => deleteApplication(element._id)}><MdDelete className="text-danger fs-2" /></button>
      </p>
     
    </div>
  </div>
  <hr/>
   </div>
   
    </>
  );
};

const EmployerCard = ({ element, openModal }) => {
  return (
    <>
     <div  className="container">
  <div className="card mb-4 w-100 p-3 mt-2  myappcard">
    <div className="row g-0">
      <div className="col-md-7 ">
        <div className="card-body pt-4">
          
          <p>
            <span className="fw-bold">Name:</span> {element.name}
          </p>
          <p>
            <span className="fw-bold">Email:</span> {element.email}
          </p>
          <p>
            <span className="fw-bold">Phone:</span> {element.phone}
          </p>
          <p>
            <span className="fw-bold">Address:</span> {element.address}
          </p>
          <p>
            <span className="fw-bold ">CoverLetter:</span> {element.coverLetter}
          </p>

         
        </div>
      </div>
      <div className="col-md-5 ps-3 pt-0">
       <center> <img
            src={element.resume.url}
            alt="resume"
            onClick={() => openModal(element.resume.url)}  className="resume"
          />  </center>
      </div>
     
    </div>
  </div>
  <hr/>
   </div>
    </>
  );
};