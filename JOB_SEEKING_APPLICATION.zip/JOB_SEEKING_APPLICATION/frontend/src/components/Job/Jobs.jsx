import React, { useContext, useEffect, useState } from "react";
import axios from "axios";
import { Link, useNavigate } from "react-router-dom";
import { Context } from "../../main";

const Jobs = () => {
  const [jobs, setJobs] = useState([]);
  const { isAuthorized } = useContext(Context);
  const navigateTo = useNavigate();
  useEffect(() => {
    try {
      axios
        .get("http://localhost:8000/api/v1/job/getall", {
          withCredentials: true,
        })
        .then((res) => {
          setJobs(res.data);
        });
    } catch (error) {
      console.log(error);
    }
  }, []);
  if (!isAuthorized) {
    navigateTo("/");
  }

  return (
    <>
      
      <div class="container-fluid">
    <div class="jobbanner">
    <p class="fw-bold fs-1 ">
      ALL AVAILBLE JOBS
    </p>
    </div>
    
    
    </div>
    <div class="container-fluid p-3 pb-5">
      <div class="row mt-5">
        {jobs.jobs &&
          jobs.jobs.map((element) => {
            return (
        <div class="col-md-3 col-sm-6 mb-3 ">
          <div class="card p-1 jobcard m-2 border border-success-subtle rounded-4" key={element._id}>
            <div class="card-body">
              <p class="card-title fs-6 fw-bold  mb-2">{element.title}</p>
              <p class="text-secondary mb-2">{element.category}</p>
              <p >{element.country}</p>
             <center> <Link to={`/job/${element._id}`}><button class="btn btn-success w-100">VIEW DETAILS</button></Link></center>
            </div>
          </div>
        </div>
        );
      })}
            </div>
         
      </div>

        
    </>
  );
};

export default Jobs;