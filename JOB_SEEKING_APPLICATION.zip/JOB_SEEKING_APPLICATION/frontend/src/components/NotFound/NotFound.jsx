import React from 'react'
import { Link } from 'react-router-dom'

const NotFound = () => {
  return (
    <>
        <section className='container mt-5'>
          <center>
            <img src="https://cdnl.iconscout.com/lottie/premium/thumb/error-404-5631135-4699354.gif" className='image-fluid' alt="notfound" />
            <br/>
            <Link to={'/'}> <button className=' btn btn-outline-success fw-bold'>RETURN TO HOME PAGE</button></Link>
        </center>
        </section>
    </>
  )
}

export default NotFound