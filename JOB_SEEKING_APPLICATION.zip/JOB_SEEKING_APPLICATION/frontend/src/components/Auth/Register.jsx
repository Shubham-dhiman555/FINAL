import React from "react";
import { useState, useContext } from "react";
import { Link, Navigate } from "react-router-dom";
import axios from "axios";
import toast from "react-hot-toast";
import { Context } from "../../main";



const Register=()=>{
    const [email, setEmail] = useState("");
    const [name, setName] = useState("");
    const [phone, setPhone] = useState("");
    const [password, setPassword] = useState("");
    const [role, setRole] = useState("Select Role");
    const[cpass,setCpass]=useState("");
  
    
    
    const reset=()=>{
        setName('');
        setEmail('');
       setPassword('');
        setPhone('');
        setCpass('');
        setRole('Select Role');
    }
    const { isAuthorized, setIsAuthorized, user, setUser } = useContext(Context);

  const handleRegister = async (e) => {
    e.preventDefault();
    try {
      const { data } = await axios.post(
        "http://localhost:8000/api/v1/user/register",
        { name, phone, email, role, password },
        {
          headers: {
            "Content-Type": "application/json",
          },
          withCredentials: true,
        }
      );
      toast.success(data.message);
      setName("");
      setEmail("");
      setPassword("");
      setPhone("");
      setRole("");
      setIsAuthorized(true);
    } catch (error) {
      toast.error(error.response.data.message);
    }
  };

  if(isAuthorized){
    return <Navigate to={'/'}/>
  }


    return(
        <>
        
        <div className=" signup container-fluid p-5 pt-0 pb-0 " >
           
            <div className="row  justify-content-center  ">
                <div className="col-lg-4  m-5  p-4 pt-0  bg-white signupform ">
                   <center><img src="/logon.png" class="logo2 "></img></center>
                <h5 className="fw-bold p-3 pt-0  text-center ">CREATE A NEW ACCOUNT</h5>
                <div className="form-group d-flex">
                    <label><i class="fa fa-user fs-4 mt-2  me-3"></i></label>
                    <select value={role}   onChange={(e) => setRole(e.target.value)}>
                  <option value="" >Select Role </option>
                  <option value="Employer"  className="text-black">Employer</option>
                  <option value="Job Seeker"  className="text-black">Job Seeker</option>
                </select>
                </div>
                <div className="form-group d-flex mt-4"> 
                 <label><i class="fa fa-user fs-4 mt-2  me-3"></i></label>  
                 <input type="text" placeholder="Your Name" className="form-control pb-2" value={name} onChange={(e)=>setName(e.target.value)}  />
                </div> <br/>
                <div className="form-group d-flex"> 
                 <label><i class="fa fa-envelope fs-4 mt-2  me-3"></i></label> 
                  <input type="email" placeholder="Your Email" className="form-control pb-2 " value={email} onChange={(e)=>setEmail(e.target.value)}  />
                </div><br/>
                <div className="form-group d-flex"> 
                 <label><i class="fa fa-key fs-4 mt-2  me-3"></i></label> 
                  <input type="password" placeholder="Password"  className="form-control pb-2" value={password} onChange={(e)=>setPassword(e.target.value)} />
                </div> <br/>
                
                    
                <div className="form-group d-flex"> 
                 <label><i class="fa fa-mobile fs-3 mt-2 me-3"></i></label> 
                  <input type="tel" placeholder="Your Mobile" className="form-control pb-2" value={phone} onChange={(e)=>setPhone(e.target.value)} />
                  
                </div>
                <div className="d-flex justify-content-between mb-4">
                    <button type="button" className="submit mt-4 ps-3 pe-3 fw-bold text-white " onClick={handleRegister}>SUBMIT</button>
                    
                    <button className=" reset mt-5  fw-bold  " onClick={reset}>Reset</button>
                    
                   
                     
                </div>
                <center>
                        
                Already have an account? <Link to="/login" className="text-danger text-center  loginbutton ">Login</Link>
                      </center>
                    

                </div>
               

            </div>

        </div>
        
        </>
    )
}
export default Register;