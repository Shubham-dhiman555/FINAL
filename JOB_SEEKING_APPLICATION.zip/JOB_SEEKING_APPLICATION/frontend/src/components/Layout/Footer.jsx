import React, { useContext } from "react";
import { Context } from "../../main";
import { Link } from "react-router-dom";
import { FaFacebookF, FaYoutube, FaLinkedin } from "react-icons/fa";
import { RiInstagramFill } from "react-icons/ri";
import { FaTwitter } from "react-icons/fa";

const Footer = () => {
  const { isAuthorized } = useContext(Context);
  return (
    <>
    <footer className={`container-fluid  ps-5 pe-5 pb-2  bg-dark ${isAuthorized ? "footerShow" : "footerHide"}`}>
      <div className="row">
     <div className="col-md-3 col-sm-4">
      <img src="/logon.png" height="60" width="170"/><br/>
      <p className="somelines pt-3">Unlocking Pathways to<br/> Dynamic Careers and<br/>Lasting Success . . . . . .</p>
    </div>
     <div className="col-md-3 col-sm-4 mb-4"> 
      <b className="text-white ">QUICK LINKS</b>
       <div className="quicklinks mt-4 ">
       <Link to={"/"} className="ql">&gt;  Home</Link>
       <Link to={"/about"} className="ql">&gt; About </Link>
      
       <Link to={"/job/getall"} className="ql">&gt; Jobs</Link>
       </div>
        
    </div>
     <div className="col-md-3 col-sm-4 ">
     <b className="text-white ">CONTACT US</b>
    

   <p className="text-secondary mt-4">SCO-22, First Floor, Ansal City Center <br/> Sector-115 Mohali (Punjab) <br/>
   

  +91 8699077540<br/>



  info@pixelsinfosys.com</p>
  <p className="text-white socialicons">
  <Link className="text-white"> <FaFacebookF className="si"/></Link> 
   <Link className="text-white"> <RiInstagramFill className="si"/></Link>
   <Link className="text-white"> <FaLinkedin className="si"/></Link>
   <Link className="text-white">  <FaTwitter className="si"/></Link>
   </p>
   



       </div>
     <div className="col-md-3  pt-0" > 
     <b className="text-white "> OUR NEWSLETTER</b>
     <p className="mt-4">
      <input type="email" className="p-2 form-control" required></input><br/>
      <Link to={"/"}><button type="submit" className="btn btn-outline-warning rounded-pill">  SUBSCRIBE</button></Link>

     </p>
     
     </div>

     
</div>
<div className="container-fluid  p-4 pb-0 mt-5">
      <center className="text-white">
        Copyright &copy; 2025 All Rights Reserved | Developed by shubham
      </center>

    </div>

    </footer>
   
  </>
  );
};

export default Footer;