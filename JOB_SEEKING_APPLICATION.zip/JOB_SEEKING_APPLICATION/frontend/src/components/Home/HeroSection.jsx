
import React from "react";
import { FaBuilding, FaSuitcase, FaUsers, FaUserPlus } from "react-icons/fa";

const HeroSection = () => {
  const details = [
    {
      id: 1,
      title: "1,23,441",
      subTitle: "Live Job",
      icon: <FaSuitcase />,
    },
    {
      id: 2,
      title: "91220",
      subTitle: "Companies",
      icon: <FaBuilding />,
    },
    {
      id: 3,
      title: "2,34,200",
      subTitle: "Job Seekers",
      icon: <FaUsers />,
    },
    {
      id: 4,
      title: "1,03,761",
      subTitle: "Employers",
      icon: <FaUserPlus />,
    },
  ];
  return (
    <>
      <div  class="container-fluid" data-aos="fade-up"data-aos-duration="3000" >
        <div id="carouselExampleCaptions" class="carousel slide carousal ">
           
            <div class="carousel-inner ">
              <div class="carousel-item active">
                {/* <img src="https://jobboard.websitelayout.net/img/banner/banner-05.jpg"  height="700" class=" w-100" alt="..."  />*/
                 <img src="/photo.png"  height="700" class=" w-100" alt="..."  /> }
                {/* <div class="carousel-caption  d-md-block pb-5 mb-5 text-start">
                  <b class="text-white fs-1">Find a <span class="text-warning">JOB </span>that suits<br/> your interests and <br/>skills</b>
                  <p class="pt-3  text-light fs-5">Find the perfect opportunity to unleash your potential and<br/> embark on a fulfilling professional journey.</p>
                </div> */}
              </div>
              
             
            </div>
            
          </div>
          <center>
          <div class="container-fluid mt-5 mb-5 herocontainer" >
           <div className="row justify-content-center">
           
           
            {details.map((element) => {
              return (
                <div className="col-lg-3 col-md-6 col-sm-6">
                <div className="card text-center  bg-light herocard m-4" key={element.id} style={{width:250}}data-aos="flip-left"
     data-aos-easing="ease-out-cubic"
     data-aos-duration="3000">
                  <div className="icon fs-1 p-2 text-success">{element.icon}</div>
                  <div className="content fw-bold">
                    <p className=" fs-5">{element.title}</p>
                    <p className="text-danger fs-5">{element.subTitle}</p>
                  </div>
                </div>
                </div>
              );
            })}
           


          </div>
         
    </div>
    </center>
    </div>
   
    </>
  );
};

export default HeroSection;